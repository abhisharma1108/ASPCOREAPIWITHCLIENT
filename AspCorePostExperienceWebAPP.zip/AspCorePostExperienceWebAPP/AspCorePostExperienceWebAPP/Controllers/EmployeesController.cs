﻿using AspCorePostExperienceWebAPP.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace AspCorePostExperienceWebAPP.Controllers
{
    public class EmployeesController : Controller
    {
        private IConfiguration _configuration;
       


        public EmployeesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        // GET: EmployeesController
        // GET: ComputerProductPortalController
        public async Task<IActionResult> Index()
        {
            List<Employee> employees = new List<Employee>();
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            //http://localhost/porductcorepublish/api/ComputerProducts
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync("/api/Employees");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                employees = JsonConvert.DeserializeObject<List<Employee>>(results);
            }

            return View(employees);
        }

        // GET: EmployeesController/Details/5
        public async Task<IActionResult> Details(int id)
        {

            Employee employee = new Employee();
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync($"/api/Employees/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employee>(result);
            }

            return View(employee);
        }

        // GET: EmployeesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeesController/Create
        // POST: ComputerProductPortalController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create(Employee employee)
        {

            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            var response = await client.PostAsJsonAsync("/api/Employees", employee);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();

        }


        // GET: EmployeesController/Edit/5
        // GET: ComputerProductPortalController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            Employee employee = new Employee();
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync($"/api/Employees/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employee>(result);
            }

            return View(employee);

        }


        // POST: EmployeesController/Edit/5
        // POST: ComputerProductPortalController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Employee employee)
        {
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            var response = await client.PutAsJsonAsync($"/api/Employees/{id}", employee);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();
        }
        // GET: ComputerProductPortalController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            Employee employee = new Employee();
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087/");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync($"/api/Employees/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                employee = JsonConvert.DeserializeObject<Employee>(result);
            }

            return View(employee);

        }

        // POST: ComputerProductPortalController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                HttpClient client = new HttpClient();
                //client.BaseAddress = new Uri("http://localhost:5087/");
                client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
                HttpResponseMessage response = await client.DeleteAsync($"/api/Employees/{id}");

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

