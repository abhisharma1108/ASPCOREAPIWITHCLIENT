﻿using AspCorePostExperienceWebAPP.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Configuration;

namespace AspCorePostExperienceWebAPP.Controllers
{
    public class PostExperiencePortalController : Controller
    {
        // GET: PostExperiencePortalController

        private IConfiguration _configuration;

        public PostExperiencePortalController(IConfiguration configuration)
        {
            _configuration = configuration;
        }




        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(Employee employee)
        {

            // PULL ALL EMPLOYEE RECORDS TO CHECK EMPLOYEE EXIST OR NOT

            List<Employee> employees = new List<Employee>();
            HttpClient client = new HttpClient();

            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync("/api/Employees");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                employees = JsonConvert.DeserializeObject<List<Employee>>(results);
            }

            //FIND EMPLOYEE  


            Employee? emp = employees.FirstOrDefault(e => e.Email == employee.Email && e.Password == employee.Password);

            if (emp != null)
            {
                HttpContext.Session.SetInt32("EmployeeId", emp.EmployeeId);


                return RedirectToAction(nameof(DashBoard));

            }
            else
            {
                ViewData["ErrorMessage"] = "Invalid User Name or password";
                return View(employee);

            }
            //if (ModelState.IsValid)
            //{
            //    _context.Add(employee);
            //    await _context.SaveChangesAsync();
            //    return RedirectToAction(nameof(Index));
            //}

        }


        // GET: PostExperiencePortalController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }
        public IActionResult LogOut()
        {

            HttpContext.Session.Clear();

            return RedirectToAction(nameof(Index));
        }

        public IActionResult SignUp()
        {
            return View();
        }

        public IActionResult AddSkills()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddSkills(Skill skill)
        {
            if (ModelState.IsValid)
            {
                int? empid = HttpContext.Session.GetInt32("EmployeeId");


                skill.EmployeeId = empid;

                HttpClient client = new HttpClient();

                client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
                var response = await client.PostAsJsonAsync("/api/Skills", skill);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(DashBoard));
                }


            }

            return View(skill);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> SignUp(Employee employee)
        {

            HttpClient client = new HttpClient();

            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            var response = await client.PostAsJsonAsync("/api/Employees", employee);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();

        }


        public async Task<IActionResult> DashBoard()
        {
            int? id = HttpContext.Session.GetInt32("EmployeeId");

            //PULL OUT EMPLOYEE DATA FROM ENDPOINT

            if (id != null)
            {
                Employee employee = new Employee();
                HttpClient client = new HttpClient();

                client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
                HttpResponseMessage response = await client.GetAsync($"/api/Employees/{id}");

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    employee = JsonConvert.DeserializeObject<Employee>(result);
                }


                ViewBag.EmpName = employee.FirstName + " " + employee.LastName;
                ViewBag.Contact = employee.LandLine + " " + employee.CellNumber;
                ViewBag.Email = employee.Email;

                // PULL OUT ALL THE SKILLS OF PARTICULAR EMPLOYEE

                List<Skill> skills = new List<Skill>();



                response = await client.GetAsync("/api/Skills");
                if (response.IsSuccessStatusCode)
                {
                    var results = response.Content.ReadAsStringAsync().Result;
                    skills = JsonConvert.DeserializeObject<List<Skill>>(results);
                }



                var appDBContext = skills.Where(s => s.EmployeeId == id); // Egar loading
                return View(appDBContext.ToList());
            }
            else
            {
                return RedirectToAction(nameof(Index));
            }


        }









        // GET: PostExperiencePortalController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PostExperiencePortalController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PostExperiencePortalController/Edit/5

        public async Task<IActionResult> Edit()
        {
            int? id = HttpContext.Session.GetInt32("EmployeeId");
            if (id == null)
            {

                return RedirectToAction(nameof(Index));

            }
            else
            {


                Employee employee = new Employee();
                HttpClient client = new HttpClient();
                //client.BaseAddress = new Uri("http://localhost:5087");
                client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
                HttpResponseMessage response = await client.GetAsync($"/api/Employees/{id}");

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    employee = JsonConvert.DeserializeObject<Employee>(result);
                }


                return View(employee);

            }




        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int EmployeeId, Employee employee)
        {
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            var response = await client.PutAsJsonAsync($"/api/Employees/{EmployeeId}", employee);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(DashBoard));
            }

            return View();
        }







        public async Task<IActionResult> Delete(int? id)
        {



            Skill skill = new Skill();
            HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("http://localhost:5087");
            client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
            HttpResponseMessage response = await client.GetAsync($"/api/Skills/{id}");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                skill = JsonConvert.DeserializeObject<Skill>(result);
            }


            

            return View(skill);
        }

        // POST: Skills/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {


            try
            {
                HttpClient client = new HttpClient();
                //client.BaseAddress = new Uri("http://localhost:5087/");
                client.BaseAddress = new Uri(_configuration["BaseAddress:Key"].ToString());
                HttpResponseMessage response = await client.DeleteAsync($"/api/Skills/{id}");

                return RedirectToAction(nameof(DashBoard));
            }
            catch
            {
                return View();
            }
        }


    }
}
