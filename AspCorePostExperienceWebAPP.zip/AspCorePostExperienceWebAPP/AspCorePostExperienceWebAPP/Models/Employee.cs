﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace AspCorePostExperienceWebAPP.Models
{
    public class Employee
    {
       
        public int EmployeeId { get; set; }

        [DisplayName("First Name")]
        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; }

        [DisplayName("Last Name")]
        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }

        [Required(ErrorMessage = "LandLine is required")]
        public string LandLine { get; set; }
        [Required(ErrorMessage = "CellNumber is required")]
        public string CellNumber { get; set; }

        [DisplayName("Email Id")]
        [Required(ErrorMessage = "Email Id is required")]

        public string Email { get; set; }
      
    }
}
