﻿using Microsoft.EntityFrameworkCore;

namespace AspCorePostExperienceWebAPI.Model
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Employee>().HasData(
            new Employee() { EmployeeId = 1, FirstName = "Abhishek", LastName = "Sharma", CellNumber = "7891234567", LandLine = "616143", Email = "abhisharmamct@gmail.com", Password = "abhi@123" }


            );

            modelBuilder.Entity<Skill>().HasData(
            new Skill() { SkillId = 1, EmployeeId = 1, SkillName = "ASP.NET CORE", Role = "TRAINER", ExperienceInYears = 5 },
             new Skill() { SkillId = 2, EmployeeId = 1, SkillName = "ANGULAR", Role = "TRAINER", ExperienceInYears = 5 }


            );
        }
    }
}
