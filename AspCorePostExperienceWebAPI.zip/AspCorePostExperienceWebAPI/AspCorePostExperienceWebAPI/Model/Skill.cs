﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AspCorePostExperienceWebAPI.Model
{
    public class Skill
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SkillId { get; set; }
        [ForeignKey("EmployeeId")]
        public int? EmployeeId { get; set; }

        [DisplayName("Skill Name")]
        [Required(ErrorMessage = "Skill can not be blank is required")]
        public string SkillName { get; set; }

        [DisplayName("Role")]
        [Required(ErrorMessage = "Role can not be blank is required")]
        public string Role { get; set; }
        [DisplayName("Experience In Years")]
        [Required(ErrorMessage = "Experience In Years can not be blank is required")]
        public int ExperienceInYears { get; set; }
        public virtual Employee Employee { get; set; }
    }
}
